package controller;

public class HelloWord {
	public static void main(String[] args) {
		
		// exibição que pula linha
		System.out.println("Olá Mundo");
		
		
	}
}
